<?php if($message = Session::get('info')): ?>
    <div class="alert alert-info text-center" role="alert" id="message">
        <?php echo e($message); ?>

    </div>
<?php endif; ?>

<style>
    .alert-info {
        background-color: #e9ecef !important;
        border-color: #e9ecef !important;
    }
</style>
<?php /**PATH C:\xampp\htdocs\aw-cms\resources\views/messages/main.blade.php ENDPATH**/ ?>