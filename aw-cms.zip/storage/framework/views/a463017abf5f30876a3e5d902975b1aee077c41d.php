<?php $__env->startSection('content'); ?>
    <div class="col-md-4 offset-4">
        <div class="center">
                    <span>
                         <a href="<?php echo e(route('welcome')); ?>"><img src="<?php echo e(asset('pictures/logo-1.png')); ?>" class="img-spacing" style="height: 60px" alt=""></a>
                    </span>
            <form method="POST" action="<?php echo e(route('registerUser')); ?>">
                <div class="form-group">
                    <label for="name">Ime</label>
                    <input type="text" class="form-control" id="name" aria-describedby="emailHelp" name="name" placeholder="Ime" required>
                </div>
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" name="email" placeholder="ime@avtowelt.com" required>
                </div>
                <div class="form-group">
                    <label for="password1">Geslo</label>
                    <small id="emailHelp" class="form-text text-muted">Minimalna dolžina 6 znakov</small>
                    <input type="password" class="form-control" id="password1" name="password1" placeholder="Geslo" required>
                </div>
                <div class="form-group">
                    <label for="password2">Geslo</label>
                    <input type="password" class="form-control" id="password2" name="password2" placeholder="Ponovite geslo" required>
                </div>
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <?php echo $__env->make('messages.login-register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
                <div class="text-center" style="padding-top: 10px;">
                    &nbsp;<a href="<?php echo e(url('/login')); ?>" class="page-links" style="text-decoration: none">Prijava</a> | <a href="<?php echo e(url('/change-password')); ?>" class="page-links" style="text-decoration: none">Pozabljeno geslo</a>
                </div>
                <button type="submit" class="btn btn-red btn-sm" style="margin: 1rem 0">Registracija</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aw-cms\resources\views/register.blade.php ENDPATH**/ ?>