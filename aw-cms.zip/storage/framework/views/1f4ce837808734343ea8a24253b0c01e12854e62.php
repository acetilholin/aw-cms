
<?php if($message = Session::get('success')): ?>
    <div class="alert alert-success" role="alert" id="message">
        <?php echo e($message); ?>

    </div>
<?php endif; ?>

<?php if($message = Session::get('error')): ?>
    <div class="alert alert-danger" role="alert" id="message">
        <?php echo e($message); ?>

    </div>
<?php endif; ?>
<?php /**PATH C:\xampp\htdocs\aw-cms\resources\views/messages/login-register.blade.php ENDPATH**/ ?>