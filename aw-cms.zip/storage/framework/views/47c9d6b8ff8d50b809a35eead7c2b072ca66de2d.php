<?php $__env->startSection('content'); ?>
    <div class="col-md-4 offset-4">
        <div class="center">
                    <span>
                         <a href="<?php echo e(route('welcome')); ?>"><img src="<?php echo e(asset('pictures/logo-1.png')); ?>" class="img-spacing" style="height: 60px" alt=""></a>
                    </span>
            <form method="POST" action="<?php echo e(route('sendToken')); ?>">
                <div class="form-group">
                    <label for="email">Email</label>
                    <input type="email" class="form-control" id="email" aria-describedby="emailHelp" name="email" placeholder="Email">
                </div>
                <input type="hidden" name="_token" value="<?php echo e(csrf_token()); ?>">
                <?php echo $__env->make('messages.login-register', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
                <div class="text-center" style="padding-top: 10px;">
                    &nbsp;<a href="<?php echo e(url('/register')); ?>" class="page-links" style="text-decoration: none">Registracija</a> | <a href="<?php echo e(url('/login')); ?>" class="page-links" style="text-decoration: none">Prijava</a>
                </div>
                <button type="submit" class="btn btn-red btn-sm" style="margin: 1rem 0">Novo geslo</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aw-cms\resources\views/password.blade.php ENDPATH**/ ?>