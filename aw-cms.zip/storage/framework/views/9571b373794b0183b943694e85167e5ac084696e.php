<?php if(isset($info)): ?>
    <div class="alert alert-info text-center" role="alert" id="message">
        <?php echo e($info); ?>

    </div>
<?php endif; ?>


<?php /**PATH C:\xampp\htdocs\aw-cms\resources\views/messages/info.blade.php ENDPATH**/ ?>