<?php $__env->startSection('content'); ?>
    <div class="col-md-4 offset-4">
        <div class="center text-center">
                    <span>
                        <img src="<?php echo e(asset('pictures/logo-1.png')); ?>" class="img-spacing" style="height: 60px">
                    </span>
            Zahtevana stran ne obstaja :(
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\aw-cms\resources\views/errors/404.blade.php ENDPATH**/ ?>