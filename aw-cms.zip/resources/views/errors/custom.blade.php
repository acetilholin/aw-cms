@extends('layouts.app')
@section('content')
    <div class="col-md-4 offset-4">
        <div class="center text-center">
                    <span>
                        <img src="{{ asset('pictures/logo-1.png') }}" class="img-spacing" style="height: 60px">
                    </span>
            Prišlo je do napake :(
        </div>
    </div>
@endsection
